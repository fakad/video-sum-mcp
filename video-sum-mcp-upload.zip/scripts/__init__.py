#!/usr/bin/env python
# -*- coding: utf-8 -*-
 
"""
辅助脚本模块
包含依赖检查、MCP包装器等工具脚本
""" 